import React, { useState } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { menuConfig } from '../config/menuConfig';
import { ChevronLeft, ChevronRight, ChevronDown, ChevronUp, User, LogOut, Settings as SettingsIcon } from 'lucide-react';

const Sidebar: React.FC = () => {
  const { user, logout } = useAuth();
  const location = useLocation();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [expandedMenus, setExpandedMenus] = useState<string[]>([]);
  const [hoverSubmenu, setHoverSubmenu] = useState<string | null>(null);

  if (!user) return null;

  const menuItems = menuConfig[user.role];

  const handleLogout = () => {
    logout();
  };

  const toggleAccordion = (itemPath: string) => {
    if (isCollapsed) return;
    
    setExpandedMenus(prev => 
      prev.includes(itemPath) 
        ? prev.filter(path => path !== itemPath)
        : [...prev, itemPath]
    );
  };

  const handleHoverSubmenu = (itemPath: string | null) => {
    if (isCollapsed) {
      setHoverSubmenu(itemPath);
    }
  };

  const profileMenuItems = [
    { label: 'Account Settings', icon: SettingsIcon, action: () => console.log('Account Settings') },
    { label: 'Logout', icon: LogOut, action: handleLogout }
  ];

  return (
    <aside className={`${isCollapsed ? 'w-16' : 'w-64'} bg-white border-r border-[#E0E0E0] min-h-screen transition-all duration-300 relative`}>
      {/* Header with Logo */}
      <div className="p-4 border-b border-[#E0E0E0]">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-[#2F80ED] rounded-md flex items-center justify-center font-bold text-white">
              D
            </div>
            {!isCollapsed && (
              <span className="text-xl font-bold text-[#1A2A4F]">Deligence.ai</span>
            )}
          </div>
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="p-1 hover:bg-[#FAFAFA] rounded transition-colors"
          >
            {isCollapsed ? (
              <ChevronRight className="w-4 h-4 text-[#828282]" />
            ) : (
              <ChevronLeft className="w-4 h-4 text-[#828282]" />
            )}
          </button>
        </div>
      </div>

      {/* Navigation Menu */}
      <div className="p-4">
        <nav className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            const isExpanded = expandedMenus.includes(item.path);
            const hasSubmenu = item.submenu && item.submenu.length > 0;
            
            return (
              <div key={item.path} className="relative">
                <div
                  onClick={(e) => {
                    if (hasSubmenu && !isCollapsed) {
                      e.preventDefault();
                      toggleAccordion(item.path);
                    } else if (isCollapsed && hasSubmenu) {
                      e.preventDefault();
                      handleHoverSubmenu(hoverSubmenu === item.path ? null : item.path);
                    }
                  }}
                  onMouseEnter={() => isCollapsed && hasSubmenu && setHoverSubmenu(item.path)}
                  onMouseLeave={() => isCollapsed && setHoverSubmenu(null)}
                  className={`flex items-center ${isCollapsed ? 'justify-center' : 'space-x-3'} px-3 py-3 rounded-lg transition-colors relative ${
                    isActive
                      ? 'bg-[#2F80ED] text-white'
                      : 'text-[#333333] hover:bg-[#FAFAFA]'
                  } ${hasSubmenu && !isCollapsed ? 'cursor-pointer' : ''}`}
                  title={isCollapsed ? item.label : ''}
                >
                  {hasSubmenu && !isCollapsed ? (
                    <>
                      <Icon className="w-5 h-5 flex-shrink-0" />
                      <span className="font-medium flex-1">{item.label}</span>
                      {isExpanded ? (
                        <ChevronUp className="w-4 h-4" />
                      ) : (
                        <ChevronDown className="w-4 h-4" />
                      )}
                    </>
                  ) : (
                    <Link to={item.path} className="flex items-center w-full">
                      <Icon className="w-5 h-5 flex-shrink-0" />
                      {!isCollapsed && (
                        <span className="font-medium ml-3">{item.label}</span>
                      )}
                    </Link>
                  )}
                </div>

                {/* Submenu for expanded state */}
                {!isCollapsed && hasSubmenu && isExpanded && (
                  <div className="ml-8 mt-2 space-y-1">
                    {item.submenu!.map((subItem, index) => (
                      <Link
                        key={index}
                        to={subItem.path}
                        className={`flex items-center space-x-2 px-3 py-2 text-sm rounded-lg transition-colors ${
                          location.pathname === subItem.path
                            ? 'bg-[#2F80ED]/10 text-[#2F80ED]'
                            : 'text-[#828282] hover:bg-[#FAFAFA] hover:text-[#333333]'
                        }`}
                      >
                        <subItem.icon className="w-4 h-4" />
                        <span>{subItem.label}</span>
                      </Link>
                    ))}
                  </div>
                )}

                {/* Hover submenu for collapsed state */}
                {isCollapsed && hoverSubmenu === item.path && hasSubmenu && (
                  <div className="absolute left-full top-0 ml-2 bg-white border border-[#E0E0E0] rounded-lg shadow-lg py-2 z-50 min-w-48">
                    <div className="px-3 py-2 text-sm font-medium text-[#828282] border-b border-[#E0E0E0]">
                      {item.label}
                    </div>
                    {item.submenu!.map((subItem, index) => (
                      <Link
                        key={index}
                        to={subItem.path}
                        className="flex items-center space-x-2 px-3 py-2 text-sm text-[#333333] hover:bg-[#FAFAFA] transition-colors"
                      >
                        <subItem.icon className="w-4 h-4" />
                        <span>{subItem.label}</span>
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </nav>
      </div>

      {/* Profile Section */}
      <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-[#E0E0E0]">
        <div className="relative">
          <button
            onClick={() => {
              if (isCollapsed) {
                handleHoverSubmenu(hoverSubmenu === 'profile' ? null : 'profile');
              }
            }}
            onMouseEnter={() => isCollapsed && setHoverSubmenu('profile')}
            onMouseLeave={() => isCollapsed && setHoverSubmenu(null)}
            className={`flex items-center ${isCollapsed ? 'justify-center' : 'space-x-3'} w-full px-3 py-3 rounded-lg hover:bg-[#FAFAFA] transition-colors`}
            title={isCollapsed ? 'Profile Menu' : ''}
          >
            <div className="w-8 h-8 bg-[#2F80ED]/10 rounded-full flex items-center justify-center flex-shrink-0">
              <User className="w-4 h-4 text-[#2F80ED]" />
            </div>
            {!isCollapsed && (
              <div className="flex-1 text-left">
                <div className="text-sm font-medium text-[#333333]">{user.name}</div>
                <div className="text-xs text-[#828282] capitalize">{user.role}</div>
              </div>
            )}
          </button>

          {/* Profile submenu for collapsed state */}
          {isCollapsed && hoverSubmenu === 'profile' && (
            <div className="absolute left-full bottom-0 ml-2 bg-white border border-[#E0E0E0] rounded-lg shadow-lg py-2 z-50 min-w-48">
              <div className="px-3 py-2 text-sm font-medium text-[#828282] border-b border-[#E0E0E0]">
                {user.name}
              </div>
              {profileMenuItems.map((item, index) => (
                <button
                  key={index}
                  onClick={item.action}
                  className="flex items-center space-x-2 w-full px-3 py-2 text-sm text-[#333333] hover:bg-[#FAFAFA] transition-colors text-left"
                >
                  <item.icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              ))}
            </div>
          )}

          {/* Profile menu for expanded state */}
          {!isCollapsed && (
            <div className="mt-2 space-y-1">
              {profileMenuItems.map((item, index) => (
                <button
                  key={index}
                  onClick={item.action}
                  className="flex items-center space-x-2 w-full px-3 py-2 text-sm text-[#333333] hover:bg-[#FAFAFA] rounded-lg transition-colors text-left"
                >
                  <item.icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;