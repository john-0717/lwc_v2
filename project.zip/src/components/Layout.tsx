import React from 'react';
import { Outlet } from 'react-router-dom';
// import Header from './Header';
import Sidebar from './Sidebar';
import { useAuth } from '../context/AuthContext';

const Layout: React.FC = () => {
  const { isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return <Outlet />;
  }

  return (
    <div className="min-h-screen bg-[#FAFAFA]">
      {/* <Header /> */}
      <div className="flex jagan">
        <Sidebar />
        {/* <main className="min-h-[calc(100vh-4rem)] w-[100%] transition-all duration-300 bg-[#f2f2f2] scrollable"> */}
        <main className="flex-1 h-screen overflow-y-auto transition-all duration-300 bg-[#f2f2f2] scrollable">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default Layout;