import React from 'react';
import { Outlet } from 'react-router-dom';
// import Header from './Header';
import Sidebar from './Sidebar';
import { useAuth } from '../context/AuthContext';

const Layout: React.FC = () => {
  const { isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return <Outlet />;
  }

  return (
    <div className="min-h-screen bg-[#FAFAFA]">
      {/* <Header /> */}
      <div className="flex">
        <Sidebar />
        <main className="flex-1 min-h-[calc(100vh-4rem)] transition-all duration-300 bg-[#f2f2f2]">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default Layout;