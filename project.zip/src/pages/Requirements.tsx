import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import RequirementCard from '../components/RequirementCard';
import { Plus, Filter, Search } from 'lucide-react';

const Requirements: React.FC = () => {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');

  // Mock data - in real app, this would come from API
  const mockRequirements = [
    {
      id: '1',
      title: 'Mobile App Development for E-commerce',
      description: 'Looking for experienced mobile developers to create a cross-platform e-commerce application with payment integration and user management.',
      budget: '$15,000 - $25,000',
      location: 'Remote',
      postedDate: '2 days ago',
      category: 'Software Development',
      urgency: 'High' as const,
      proposalsCount: 12
    },
    {
      id: '2',
      title: 'Digital Marketing Campaign Strategy',
      description: 'Need a comprehensive digital marketing strategy for product launch including social media, content marketing, and SEO optimization.',
      budget: '$5,000 - $10,000',
      location: 'New York, NY',
      postedDate: '1 week ago',
      category: 'Marketing',
      urgency: 'Medium' as const,
      proposalsCount: 8
    },
    {
      id: '3',
      title: 'Cloud Infrastructure Setup',
      description: 'Require expertise in setting up scalable cloud infrastructure on AWS with proper security measures and monitoring systems.',
      budget: '$8,000 - $12,000',
      location: 'Remote',
      postedDate: '3 days ago',
      category: 'DevOps',
      urgency: 'High' as const,
      proposalsCount: 15
    }
  ];

  const handleShowInterest = () => {
    alert('Interest shown! Chat will be enabled with the industry.');
  };

  const handleSendQuotation = () => {
    alert('Quotation form opened! After sending, chat will be enabled.');
  };

  const handleViewChats = () => {
    alert('Opening chat list with interested professionals and vendors.');
  };

  const getPageTitle = () => {
    switch (user?.role) {
      case 'industry': return 'My Requirements';
      case 'professional': return 'Available Opportunities';
      case 'vendor': return 'Business Requirements';
      default: return 'Requirements';
    }
  };

  const getPageDescription = () => {
    switch (user?.role) {
      case 'industry': return 'Manage your posted requirements and view proposals from professionals and vendors.';
      case 'professional': return 'Browse available opportunities and show interest to connect with industries.';
      case 'vendor': return 'Find business requirements and submit quotations to potential clients.';
      default: return 'Browse requirements and opportunities.';
    }
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-[#333333] mb-2">{getPageTitle()}</h1>
          <p className="text-[#828282]">{getPageDescription()}</p>
        </div>
        {user?.role === 'industry' && (
          <button className="flex items-center space-x-2 bg-[#2F80ED] text-white px-6 py-3 rounded-lg hover:bg-[#1A2A4F] transition-colors">
            <Plus className="w-4 h-4" />
            <span>Post Requirement</span>
          </button>
        )}
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6 grid-cols-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[#828282] w-4 h-4" />
          <input
            type="text"
            placeholder="Search requirements..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className=" pl-10 pr-4 py-3 border border-[#E0E0E0] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#2F80ED] focus:border-transparent"
          />
        </div>
        <div className="relative">
          <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[#828282] w-4 h-4" />
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="pl-10 pr-8 py-3 border border-[#E0E0E0] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#2F80ED] focus:border-transparent bg-white"
          >
            <option value="all">All Categories</option>
            <option value="software">Software Development</option>
            <option value="marketing">Marketing</option>
            <option value="design">Design</option>
            <option value="devops">DevOps</option>
          </select>
        </div>
      </div>

      {/* Requirements Grid */}
      <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {mockRequirements.map((requirement) => (
          <RequirementCard
            key={requirement.id}
            {...requirement}
            userRole={user?.role || 'professional'}
            onShowInterest={handleShowInterest}
            onSendQuotation={handleSendQuotation}
            onViewChats={handleViewChats}
          />
        ))}
      </div>

      {mockRequirements.length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-[#E0E0E0] rounded-full flex items-center justify-center mx-auto mb-4">
            <Search className="w-8 h-8 text-[#828282]" />
          </div>
          <h3 className="text-lg font-medium text-[#333333] mb-2">No requirements found</h3>
          <p className="text-[#828282]">Try adjusting your search or filter criteria.</p>
        </div>
      )}
    </div>
  );
};

export default Requirements;