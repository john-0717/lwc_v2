import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";

interface UserData {
  id: string;
  email: string;
  name: string;
  picture?: string;
  phone?: string;
  address?: string;
  dateOfBirth?: string;
  occupation?: string;
  church?: string;
  interests: string[];
  prayerRequests?: string;
  testimony?: string;
  emergencyContact?: {
    name: string;
    phone: string;
    relationship: string;
  };
  preferences: {
    emailNotifications: boolean;
    prayerUpdates: boolean;
    eventReminders: boolean;
    newsletter: boolean;
  };
  role?: "admin" | "writer" | "member";
  joinDate?: string;
}

interface AuthContextType {
  user: UserData | null;
  isAuthenticated: boolean;
  login: (userData: UserData) => void;
  logout: () => void;
  updateUser: (userData: Partial<UserData>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<UserData | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Load user from localStorage on app start
  useEffect(() => {
    const savedUser = localStorage.getItem("lwc_user") || `{
  "id": "12345",
  "email": "john.doe@example.com",
  "name": "John Doe",
  "picture": "https://example.com/john.jpg",
  "phone": "555-1234",
  "address": "123 Main St, Springfield, USA",
  "dateOfBirth": "1990-06-15",
  "occupation": "Software Developer",
  "church": "Springfield Church",
  "interests": ["Technology", "Reading", "Traveling", "Music"],
  "prayerRequests": "Praying for family and work life balance.",
  "testimony": "I came to faith through a series of personal struggles, but God has been faithful.",
  "emergencyContact": {
    "name": "Jane Doe",
    "phone": "555-5678",
    "relationship": "Wife"
  },
  "preferences": {
    "emailNotifications": true,
    "prayerUpdates": true,
    "eventReminders": true,
    "newsletter": false
  },
  "role": "member",
  "joinDate": "2022-03-15"
}`;
    if (savedUser) {
      try {
        const userData = JSON.parse(savedUser);
        setUser(userData);
        setIsAuthenticated(false);
      } catch (error) {
        console.error("Error loading saved user:", error);
        localStorage.removeItem("lwc_user");
      }
    }else{
        setIsAuthenticated(true);

    }
  }, []);

  const login = (userData: UserData) => {
    const userWithDefaults = {
      ...userData,
      role: userData.role || "member",
      joinDate: userData.joinDate || new Date().toISOString().split("T")[0]
    };
    
    setUser(userWithDefaults);
    setIsAuthenticated(true);
    localStorage.setItem("lwc_user", JSON.stringify(userWithDefaults));
    
    // Here you would typically also send the data to your Node.js backend
    // sendUserDataToBackend(userWithDefaults);
  };

  const logout = () => {
    setUser(null);
    setIsAuthenticated(false);
    localStorage.removeItem("lwc_user");
    
    // Clear any other auth-related data
    // You might also want to call your backend to invalidate the session
  };

  const updateUser = (updatedData: Partial<UserData>) => {
    if (user) {
      const updatedUser = { ...user, ...updatedData };
      setUser(updatedUser);
      localStorage.setItem("lwc_user", JSON.stringify(updatedUser));
      
      // Send updated data to backend
      // updateUserDataInBackend(updatedUser);
    }
  };

  // Function to send user data to your Node.js backend
  const sendUserDataToBackend = async (userData: UserData) => {
    try {
      const response = await fetch("/api/users", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(userData),
      });

      if (!response.ok) {
        throw new Error("Failed to save user data to backend");
      }

      const result = await response.json();
      console.log("User data saved to backend:", result);
    } catch (error) {
      console.error("Error saving user data to backend:", error);
    }
  };

  const value = {
    user,
    isAuthenticated,
    login,
    logout,
    updateUser
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};